/*
 * udpclient.c
 *
 *  Created on: Dec 21, 2025
 *      Author: Rama Syafrizal
 *
 *      modify from controllertech
 */


/* ===================== Includes ===================== */
#include "cmsis_os.h"

#include "lwip/opt.h"
#include "lwip/api.h"
#include "lwip/sys.h"
#include "lwip.h"
#include "lwip/udp.h"
#include "lwip/pbuf.h"
#include "lwip/ip_addr.h"
#include "functionMath.h"

#include <string.h>
#include "main.h"
#include "udpclient.h"

/* ===================== Static Objects ===================== */
static struct netconn *conn;
static struct netbuf  *rxbuf, *buf;
static struct udp_pcb *upcb;
struct pbuf *prx;
u16_t len;

//static struct udp_pcb *upcb_rx;
//static struct udp_pcb *upcb_tx;
static ip_addr_t destIP;

/* ===================== Global Variables ===================== */
//int indx = 0;

//char smsg[200];
//uint32_t buffer = 0;

uint16_t data1,data2;
uint16_t sequence = 0;
float data_trq = 0.0f;
float data_Vx = 0.0f;
float data_Vx_Wheel = 0.0f;
float data_Vx_Thrl = 0.0f;
float data_Steer_Wheel = 0.0f;
uint32_t timestamp = 0;
int32_t data_Mzd = 0;
uint16_t adcData = 0;

//Latency
int Latency = 0;
double Latency_s = 0.0f;

/* ===================== Application State ===================== */
EthMode_t      currEthMode = SEND_TO_VCU;
CobaData	   cd;
VCUToCorner    v2c;
VCUToCorner_Latency v2c_l;
Latency_sendBack lsb;
Latency_send ls;
Micro2Micro    m2m;
PCToVCU_Latency p2v;

/* ===================== Function Prototypes ===================== */
void udpsend(char *data);
void udpsend_hex(const void *data, uint16_t len);


void HIL_ETH_ToggleMode(void) {
    if (currEthMode == SEND_TO_MATLAB)
        currEthMode = SEND_TO_VCU;
    else
        currEthMode = SEND_TO_MATLAB;
}

static void udpinit_thread(void *arg)
{
    err_t err, recv_err;
    upcb = udp_new();

    /* Create new UDP netconn */
    conn = netconn_new(NETCONN_UDP);

    if (conn == NULL)
    {
        netconn_delete(conn);
        vTaskDelete(NULL);
        return;
    }

    /* Bind to local port */
    err = netconn_bind(conn, IP_ADDR_ANY, CORNER_PORT);
    if (err != ERR_OK)
    {
        netconn_delete(conn);
        vTaskDelete(NULL);
        return;
    }

//    netconn_set_recvtimeout(conn, 5);

    /* Destination IP address */
    /* specialy for udpsend */
    IP_ADDR4(&destIP, 10, 252, 62, 212);

    /* Connect to destination port */
//    err = netconn_connect(conn, &destIP, destPort);
//    if (err != ERR_OK)
//    {
//        netconn_delete(conn);
//        vTaskDelete(NULL);
//        return;
//    }

    /* Infinite receive loop */
    for (;;)
    {
        recv_err = netconn_recv(conn, &rxbuf);

        if (recv_err == ERR_OK && rxbuf != NULL)
        {
			memcpy(&v2c, rxbuf->p->payload,sizeof(VCUToCorner));
			if(v2c.Header == VCU_FRAME_HEADER && v2c.id == CORNER_FRAME_ID)
			{
				//Extract data
				data_trq         = v2c.Trq;
				data_Vx          = v2c.Vx;
				data_Vx_Wheel    = v2c.Vx_Wheel;
				data_Vx_Thrl     = v2c.Vx_Thrl;
				data_Steer_Wheel = v2c.Steer_Wheel;
				data_Mzd         = v2c.Mzd;
				sequence	     = v2c.seq;

				data_trq         = (data_trq / 100) - 120;
				data_Vx          = data_Vx / 100;
				data_Vx_Wheel    = data_Vx_Wheel / 100;
				data_Vx_Thrl     = data_Vx_Thrl / 100;
				data_Steer_Wheel = (data_Steer_Wheel / 100) - 40;
				data_Mzd	     =  data_Mzd - 40000;
			}

			//Release buffer
			netbuf_delete(rxbuf);
        }
    }
}

/*-------UDP Send function to send the data to the server-------------*/
void udpsend (char *data)
{
	buf = netbuf_new();   // Create a new netbuf
	netbuf_ref(buf, data, strlen(data));  // refer the netbuf to the data to be sent 
	netconn_send(conn,buf);  // send the netbuf to the client
	netbuf_delete(buf);  // delete the netbuf
}

void udpsend_hex(const void *data, uint16_t len)
{
	//udp_pcb
//    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_RAM);
//    if (p != NULL) {
//        memcpy(p->payload, data, len);
//        udp_sendto(upcb, p, &destIP, destPort);
//        pbuf_free(p);
//    }

    //netconn
    struct netbuf *nbuf = netbuf_new();
    if (nbuf == NULL) return;

    void *payload = netbuf_alloc(nbuf, len);
    memcpy(payload, data, len);

//    netconn_send(conn, nbuf);
    netconn_sendto(conn, nbuf, &destIP, MATLAB_PORT);
    netbuf_delete(nbuf);
}

/* UDP send Thread will send data every 500ms */
//static void udpsend_thread(void *arg)
//{
//	for (;;)
//	{
//		sprintf (smsg, "index value = %d\n", indx++);
//		udpsend(smsg);
//		osDelay(500);
//	}
//}


void udpclient_init(void)
{
//	sys_thread_new("udpsend_thread", udpsend_thread, NULL, DEFAULT_THREAD_STACKSIZE,osPriorityNormal);
	sys_thread_new("udpinit_thread", udpinit_thread, NULL, 256,osPriorityNormal);
}


